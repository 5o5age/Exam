import work.Run;

public class main {                                               
    public static void main(String[] args) {        //                              MOVORA | Movie sorting app                                  \\
        Run.run();                                 //                                   Press: F5 to START                                       \\
    }                                             //                                                                                              \\
}                                                //         If help needed, please reffer to our website: https://5o5age.github.io/Movora/         \\
                                                //                          where you can access manual and contact information.                    \\
                                               //====================================================================================================\\